package com.demo.capstore.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "customer" ,uniqueConstraints=
	@UniqueConstraint(columnNames={"email"})
)
public class Customer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="customerId",unique=true, nullable=false)
	private int customerId;
	
	@NotNull(message="The cutomerName must be present")
	private String customerName;
	
	@Column(name="mobileNo", nullable=false)
	@NotNull(message="The mobileNo must be present")
	private String mobileNo;
	
	@Column(name="age", nullable=false)
	@Min(value=0, message="Age cannot be less than 1")
	@NotNull(message="The age must be captured")
	private int age;
	
	@Column(name="email", nullable=false)
	@NotNull(message="The email must be captured")
	private String email;
	
	@Column(name="password", nullable=false)
	@NotNull(message="The password must be captured")
	private String password;
	
	@NotNull(message="The address must be captured")
	@ManyToOne(optional = false)
    @JoinColumn(name = "address", referencedColumnName = "id")
	private Address address;
	
	@Transient
	@JsonIgnore
    private String passwordConfirm;
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	

	


	public Customer(int customerId, @NotNull(message = "The cutomerName must be present") String customerName,
			@NotNull(message = "The mobileNo must be present") String mobileNo,
			@Min(value = 0, message = "Age cannot be less than 1") @NotNull(message = "The age must be captured") int age,
			@NotNull(message = "The email must be captured") String email,
			@NotNull(message = "The password must be captured") String password,
			@NotNull(message = "The address must be captured") Address address, String passwordConfirm) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.mobileNo = mobileNo;
		this.age = age;
		this.email = email;
		this.password = password;
		this.address = address;
		this.passwordConfirm = passwordConfirm;
	}






	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPasswordConfirm() {
		return passwordConfirm;
	}

	public void setPasswordConfirm(String passwordConfirm) {
		this.passwordConfirm = passwordConfirm;
	}



	public Address getAddress() {
		return address;
	}



	public void setAddress(Address address) {
		this.address = address;
	}



	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", mobileNo=" + mobileNo
				+ ", age=" + age + ", email=" + email + ", password=" + password + ", address=" + address
				+ ", passwordConfirm=" + passwordConfirm + "]";
	}



	

	
}