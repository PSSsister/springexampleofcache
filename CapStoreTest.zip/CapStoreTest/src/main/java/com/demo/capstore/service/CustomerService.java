package com.demo.capstore.service;

import java.util.List;

import javax.validation.Valid;

import com.demo.capstore.exception.ResourceNotFoundException;
import com.demo.capstore.model.Customer;

public interface CustomerService {

	public List<Customer> findAllCustomer();

	public Customer findById(int customerId) throws ResourceNotFoundException;

	public Customer addDetails(@Valid Customer customer);

	public String customerSignIn(String email, String password) throws ResourceNotFoundException;

	public String resetCustomerPassword(String email, String password, String newPassword) throws ResourceNotFoundException;

}
