package com.demo.capstore.service;

import com.demo.capstore.sto.DtoResponse;

public interface ICacheData {

	DtoResponse getDataCache(int id);

	void flushCache();

}
