package com.demo.capstore.sto;

import org.springframework.http.HttpStatus;

import com.demo.capstore.model.Customer;

import lombok.Data;

@Data
public class DtoResponse {
	long interval;
	HttpStatus httpStatus;
	Customer customer;
	public long getInterval() {
		return interval;
	}
	public void setInterval(long interval) {
		this.interval = interval;
	}
	public HttpStatus getHttpStatus() {
		return httpStatus;
	}
	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	
}
