package com.demo.capstore.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.demo.capstore.dao.CustomerRepository;
import com.demo.capstore.model.Customer;
import com.demo.capstore.sto.DtoResponse;

@Component
public class CacheDataImp implements ICacheData{
	@Autowired
	CustomerRepository customerRepository;
	
	@Override	
    @Cacheable(cacheNames="headers", condition="#id > 1")
	public DtoResponse getDataCache(int id) {	
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		DtoResponse requestResponse=new DtoResponse();		
		Optional<Customer> invoice=customerRepository.findById(id);
		
		 if (invoice.isPresent())
		 {
			 requestResponse.setCustomer(invoice.get());
			 requestResponse.setHttpStatus(HttpStatus.OK);
			 return requestResponse;
		 }
		 requestResponse.setHttpStatus(HttpStatus.NOT_FOUND);
		 return requestResponse;		
	}
	
	@Override
	@CacheEvict(cacheNames="headers", allEntries=true)
	public void flushCache() {		
	}

}
