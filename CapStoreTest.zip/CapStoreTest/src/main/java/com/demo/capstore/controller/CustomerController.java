package com.demo.capstore.controller;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.capstore.exception.ResourceNotFoundException;
import com.demo.capstore.model.Customer;
import com.demo.capstore.service.CustomerService;

@RestController
@CrossOrigin(origins = "/*")
@RequestMapping("/api/v1/")
public class CustomerController {
	private Logger LOG = LoggerFactory.getLogger(CustomerController.class);
	@Autowired
	CustomerService customerService;
	
	
	@GetMapping("customer")
	public ResponseEntity<List<Customer>> getAllCustomerDetails() {
		return new ResponseEntity<List<Customer>>(customerService.findAllCustomer(), HttpStatus.OK);
	}
	
	@GetMapping("customer/{customerId}")
	public ResponseEntity<Customer> getCustomerById(@PathVariable(value = "customerId") int customerId) throws ResourceNotFoundException {
		return new ResponseEntity<Customer>(customerService.findById(customerId), HttpStatus.OK);
	}
	
	@PostMapping("/customer")
	public ResponseEntity<Customer> customerRegistration(@RequestBody @Valid Customer customer) {
		return new ResponseEntity<Customer>(customerService.addDetails(customer), HttpStatus.CREATED);
	}
	
	@GetMapping("/customer/signin")
	public ResponseEntity<String> customerLogin(@RequestHeader MultiValueMap<String, String> headers,@RequestParam(value = "email",required = true) String email, @RequestParam(value = "password", required = true) String password) throws ResourceNotFoundException {
		headers.forEach((key, value) -> {
	        LOG.info(String.format(
	          "Header '%s' = %s", key, value.stream().collect(Collectors.joining("|"))));
	    });
		return new ResponseEntity<String>(customerService.customerSignIn(email, password), HttpStatus.OK);
	}
	
	@PatchMapping("/customer/resetPassword")
	public ResponseEntity<String> resetPassword(@RequestParam(value = "email", required = true) String email, @RequestParam(value= "password", required = true) String password, @RequestParam(value = "newPassword", required = true) String newPassword) throws ResourceNotFoundException{
		return new ResponseEntity<String>(customerService.resetCustomerPassword(email, password, newPassword), HttpStatus.OK);
	}
	
	
	

}
