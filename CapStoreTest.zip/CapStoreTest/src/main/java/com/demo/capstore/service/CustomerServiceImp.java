package com.demo.capstore.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.capstore.dao.CustomerRepository;
import com.demo.capstore.exception.ResourceNotFoundException;
import com.demo.capstore.model.Customer;

@Service
@Transactional(readOnly = true)
public class CustomerServiceImp implements CustomerService{
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public List<Customer> findAllCustomer() {	
		return customerRepository.findAll();
	}

	@Override
	public Customer findById(int customerId) throws ResourceNotFoundException {
		return customerRepository.findById(customerId).map(customer -> {
            return customer;
        }).orElseThrow(() -> new ResourceNotFoundException("Customer with customerId " + customerId + " is not found in database."));	
	}

	@Override
	@Transactional
	public Customer addDetails(@Valid Customer customer) {
		return customerRepository.save(customer);
	}

	@Override
	public String customerSignIn(String email, String password) throws ResourceNotFoundException {
		return customerRepository.findByEmailAndPassword(email,password).map(result -> {
            return "Login Successful";
        }).orElseThrow(() -> new ResourceNotFoundException("Customer with email " + email + " is not found in database."));	
	}

	@Override
	@Transactional
	public String resetCustomerPassword(String email, String password, String newPassword) throws ResourceNotFoundException {
		return customerRepository.findByEmailAndPassword(email, password).map(customer -> {
			customer.setPassword(newPassword);
            return "Password Reset Successfully";
        }).orElseThrow(() -> new ResourceNotFoundException("Customer is not found in database."));	
	}

}
